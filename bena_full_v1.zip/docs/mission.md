# Mission
Enable anyone to earn fairly using the device they already have.