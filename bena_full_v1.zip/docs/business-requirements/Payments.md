# Payments Requirements
Stablecoin core + regional cash-out.