# Philosophy
Bena is built on dignity, transparency, and global uplift.