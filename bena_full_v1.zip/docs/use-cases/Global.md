# Global Use Cases
Tasks and flows across PH, Africa, EU, US, LatAm, AU.