# Task Model
RTFN, scheduled, digital.