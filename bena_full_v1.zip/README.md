# Bena

A global, open-source human empowerment platform enabling anyone, anywhere to earn through real-world and digital tasks.