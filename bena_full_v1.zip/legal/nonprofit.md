# Nonprofit Structure
Initial framing for 501(c)(3) or global equivalent.